#region usings
using System;
using System.ComponentModel.Composition;

using VVVV.PluginInterfaces.V1;
using VVVV.PluginInterfaces.V2;
using VVVV.Utils.VColor;
using VVVV.Utils.VMath;

using VVVV.Core.Logging;
#endregion usings

namespace VVVV.Nodes
{
	#region PluginInfo
	[PluginInfo(Name = "SpellValueJP", Category = "Value", Help = "Int value to JP Kansuji", Tags = "")]
	#endregion PluginInfo
	public class ValueSpellValueJPNode : IPluginEvaluate
	{
		#region fields & pins
		[Input("Value", DefaultValue = 0)]
		public ISpread<int> FInput;

		[Output("Kansuji")]
		public ISpread<String> FOutput;

		[Import()]
		public ILogger FLogger;
		#endregion fields & pins

		//called when data for any output pin is requested
		public void Evaluate(int SpreadMax)
		{
			FOutput.SliceCount = SpreadMax;

			for (int i = 0; i < SpreadMax; i++)
				FOutput[i] = toKansuji(FInput[i]);

			//FLogger.Log(LogType.Debug, "hi tty!");
		}
		
		private string toKansuji(int number) {
   			if (number == 0) {
        		return "〇";
   			}
        
    		string[] kl = new string[] { "", "十", "百", "千" };
    		string[] tl = new string[] { "", "万", "億", "兆", "京" };
    		string[] nl = new string[] { "", "一", "二", "三", "四", "五", "六", "七", "八", "九" };
    		string str = "";
    		int keta = 0;
    		while (number > 0) {
        		int k = keta % 4;
        		int n = (int)(number % 10);
                
        		if (k == 0 && number % 10000 > 0) {
            		str = tl[keta / 4] + str;
        		}
                
        		if (k != 0 && n == 1) {
            		str = kl[k] + str;
        		} else if (n != 0) {
            		str = nl[n] + kl[k] + str;
        		}
                
        		keta++;
        		number /= 10;
    		}
    		return str;
		}
	}
}
